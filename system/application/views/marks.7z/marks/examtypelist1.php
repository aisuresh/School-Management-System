<?php
  echo '<table class="reporttable" border="0" cellpadding="0" cellspacing="1" >  
        <tr><th colspan = "7" id = "table_title">Mark Detail List View </th></tr>

				   <tr id="recordtitle" >
					    <th align="center" >S.No</th>
						<th align="center" ><input type = "hidden" name = "tablename" class="MarksId" id ="ordertype"  value = "0" /> </th>
						<th align="center" >ExamType</th>
						
						
						
											
						
					</tr>';
   
	
	      $i = 1;
		foreach($result as $row){
		            echo '<tr>
					<tr id="recordtitlevalue">
					<td align="center" >' . $i++. '</td>
					<td align="center" ><input type="radio" name = "MarksId" id = "MarksId" value =' . $row->MarksId . '/></td>	
		
					<td align="center">'.$row->ExamType. '</td>
					<td align="center">
					<table border="1">
						<tr>
							<th align="center">Subject</th>
							<th align="center">Marks</th>
							
							
						</tr>';
						
							
$subarray = explode(',', $row->Marks);	
	
						
foreach($subjects as $sub){
  echo '<tr><td>'.$sub->SubjectName .'</td></tr>';
	//echo '<td>'.$subarray.'</td></tr>';
}

foreach($subarray as $id=>$value){


echo '<tr><td>'.$value.'</td></tr>';
}

					echo '</table>
					</td>';
					
		           
					
		
		echo '</tr>';
	}       
		   
echo '</table>';    
echo "<div class='pagenation'>" . $links . "</div>";
echo "</div>";
echo "</div>";
?>
